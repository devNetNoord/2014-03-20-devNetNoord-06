﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AwaitIsNotParallel
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch sw = Stopwatch.StartNew();
            Run().Wait();
            sw.Stop();
            Console.WriteLine(sw.ElapsedMilliseconds);
            sw.Restart();
            RunParallel().Wait();
            sw.Stop();
            Console.WriteLine(sw.ElapsedMilliseconds);
        }

        private async static Task RunParallel()
        {
            Task a = A(); // A takes 1 second
            Task b = B(); // B takes 2 seconds

            await Task.WhenAll(a, b);
        }

        private async static Task Run()
        {
            await A(); // A takes 1 second
            await B(); // B takes 2 seconds
        }

        private static Task A()
        {
            return Task.Delay(1000);
        }
        private static Task B()
        {
            return Task.Delay(2000);
        }
    }
}
