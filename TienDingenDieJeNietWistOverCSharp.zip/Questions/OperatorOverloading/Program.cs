﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperatorOverloading
{
    class Program
    {
        static void Main(string[] args)
        {
            var a = "dev";
            var b = " Net ";
            var c = "Noord";

            Console.WriteLine(a + b + c);
            // Displays devNetNoord
        }
    }

    class var
    {
        private string _s;
        var(string s)
        {
            _s = s.Trim();
        }

        public static implicit operator var(string s)
        {
            return new var(s);
        }

        public static implicit operator string(var s)
        {
            return s._s;
        }

        public static var operator +(var c1, var c2)
        {
            return new var(c1._s + c2._s);
        }
    
    }
}
