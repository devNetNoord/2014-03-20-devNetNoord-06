﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YieldQuestion
{
    class Program
    {
        static void Main()
        {
            CapitalLetters(null);
        }

        static IEnumerable<char> CapitalLetters(string input)
        {
            if (input == null)
            {
                throw new ArgumentNullException(input);
            }
            foreach (char c in input)
            {
                yield return char.ToUpper(c);
            }
        }
    }
}
