﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace AsyncAwaitWrongUse.Controllers
{
    public class HomeController : Controller
    {
        public async Task<ViewResult>Index()
        {
            var pi = await Task.Run<double>(MathHelper.CalculatePi(1000));

            return View(pi);
        }
    }


    public static class MathHelper
    {
        public static Func<double> CalculatePi(double p)
        {
            return () => 10;
        }
    }
}