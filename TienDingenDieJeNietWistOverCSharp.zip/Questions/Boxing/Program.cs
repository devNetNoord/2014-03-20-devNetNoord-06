﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boxing
{
    class Program
    {
        static void Main(string[] args)
        {
            Foo<int>();
            Foo<int?>(); 
        }
        
        static void Foo<T>() where T : new()
        {
            T t = new T();
            Console.WriteLine("ToString: " + t.ToString());
            Console.WriteLine("GetHashCode: " + t.GetHashCode());
            Console.WriteLine("Equals: " + t.Equals(t));
            Console.WriteLine("GetType: " + t.GetType());
        }
    }
}
