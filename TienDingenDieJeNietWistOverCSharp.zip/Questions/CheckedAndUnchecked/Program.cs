﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckedAndUnchecked
{
    class Program
    {
        static void Main(string[] args)
        {
           // int i1 = 2147483647 + 10;
            
            int ten = 10;
            int i2 = 2147483647 + ten;
            // -2147483639

            // checked { }
            // unchecked { }
        }
    }
}
