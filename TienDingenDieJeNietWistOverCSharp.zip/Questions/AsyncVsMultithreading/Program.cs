﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AsyncVsMultithreading
{
    class Program
    {
        static void Main(string[] args)
        {
            RunIO().Wait();

            RunCPU().Wait();
        }

        private async static Task<int> RunCPU()
        {
            string content = await Task.Run<string>(() => "Hello devNetNoord!");
            return content.Length;
        }

        private async static Task<int> RunIO()
        {
            HttpClient client = new HttpClient();
            string result = await client.GetStringAsync("http://www.devnetnoord.nl");
            return result.Length;
        }
    }
}
