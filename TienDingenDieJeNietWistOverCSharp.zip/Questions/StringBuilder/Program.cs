﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringBuilderQuestion
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 100000000;

            Stopwatch sw = Stopwatch.StartNew();

            for (int x = 0; x < i; x++)
            {
                A("1", "2", "3");
            }

            sw.Stop();
            Console.WriteLine(sw.ElapsedMilliseconds);
            sw.Restart();
            for (int x = 0; x < i; x++)
            {
                B("1", "2", "3");
            }
            sw.Stop();

            Console.WriteLine(sw.ElapsedMilliseconds);
            
        }
        private static string A(string a, string b, string c)
        {
            string result = "{a:" + a + ", b:" + b + ", c:" + c + "}";
            return result;
        }

        private static string B(string a, string b, string c)
        {
            StringBuilder sb = new StringBuilder(100);
            string result = sb.Append("{a:").Append(a)
                  .Append(", b:").Append(b)
                  .Append(", c:").Append(c)
                  .Append("}")
                  .ToString();
            return result;
        }


    }
}
