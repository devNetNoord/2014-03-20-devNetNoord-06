﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace LinqQuestion
{
    static class LinqExtensions
    {
        public static IEnumerable<T> Select<T>(this IEnumerable<T> elements, Func<T, T> i)
        {
            int index = 0;
            foreach (T element in elements)
            {
                if (index % 2 == 0)
                    yield return element;

                index++;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            var result = from i in new List<int> { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 }
                         select i;
            foreach (var r in result) Console.Write(r);
            // Displays 02468
        }
    }
}
