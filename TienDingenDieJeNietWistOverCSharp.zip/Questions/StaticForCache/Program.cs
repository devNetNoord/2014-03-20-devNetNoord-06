﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticForCache
{
    class Program
    {
        static List<Order> cache;

        void Run()
        {
            if (cache == null)
            {
                cache = FetchItems();
            }

            // work with cache
        }

        private static List<Order> FetchItems()
        {
            throw new NotImplementedException();
        }
    }

    public static class Cache
    {

    }
}
